<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../ASSETS/rodape.css">
    <link rel="stylesheet" type="text/css" href="../ASSETS/naoautorizado.css">
    <title> NÃO AUTORIZADO!</title>
</head>

<body>
    <div class="content">
        <img src="../ASSETS/imgs/admin/autorizado.png">
    </div>
</body>